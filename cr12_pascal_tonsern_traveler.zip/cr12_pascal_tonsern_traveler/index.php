<?php get_header(); ?>
      <div class="row">

        <div class="col-xs-10 blog-main">

          <?php if (have_posts()) : while (have_posts()) : the_post(); ?>

          <div class="blog-post col-md-5 col-xs-8 p-2 ">
            <h2 class="blog-post-title">
              <a href="<?php the_permalink(); // href to a specific blog post ?>">
                <?php the_title(); // blog post title ?>
              </a>
            </h2>
            <p class="blog-post-meta"><?php the_time('d.m.Y G:i'); // blog post date and time ?>
              by <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')) ?>"> <?php the_author(); // blog post author ?> </a></p>

          <?php if(has_post_thumbnail()) : ?>

            <div class="post-thumb">
              <?php the_post_thumbnail(); ?>
            </div>
          <?php endif; ?>

            <p><?php the_excerpt(); // blog post content ?>
            </p>
            
         </div><!-- /.blog-post -->
          <?php endwhile; else:  ?>
          <div class="blog-post">
            <h2 class="blog-post-title"><?php echo('No Posts Found'); ?></h2>
          </div><!-- /.blog-post -->
          <?php endif; ?>


        </div><!-- /.blog-main -->

        <div class="col-xs-2 blog-sidebar">
          <div class="sidebar-module sidebar-module-inset">
            <?php
             if(is_active_sidebar('sidebar')):
             dynamic_sidebar('sidebar');
             endif;
            ?>
          </div>
        </div><!-- /.blog-sidebar -->

      </div><!-- /.row -->

    </div><!-- /.container -->

<?php get_footer(); ?>